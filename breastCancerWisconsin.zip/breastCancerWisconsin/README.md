##### Summary:
This project was from a kaggle dataset at https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data. I selected it because it had a large amount of predictor variables for me to work with as I practiced standardizing data. I use a standardscaler function but link a website with further options for scaling that I could practice with in the future. The data itself is not what initially intrigued me, though I am quite curious about the effects of machine learning in the medical field, and this was a great chance to practice it.

##### Organization of the Folder:
This folder contains my python code and the data in a csv file. 