'''
https://www.kaggle.com/code/gargmanish/basic-machine-learning-with-cancer
'''
### Libraries
import pandas as pd
import numpy as np
import random as rnd

from sklearn.model_selection import train_test_split

### ML Models to be used
from sklearn import preprocessing
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import Perceptron
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

###################################################################
###################    Cleaning the Data   ########################
###################################################################
df = pd.read_csv(r'C:/Users/clays/OneDrive/Documents/GitHub/breastCancerWisconsin/data.csv')


Y = df['diagnosis']
X = df.drop(["diagnosis", "id"], axis = 'columns')


### https://www.kaggle.com/code/discdiver/guide-to-scaling-and-standardizing ###
# Website for using different types of scaling: robust scaling, standard, and normal. 
# Using standard scaler
col_names = list(X.columns)
s_scaler = preprocessing.StandardScaler()
X_s = s_scaler.fit_transform(X)
X_s = pd.DataFrame(X_s, columns=col_names)

X_train, X_test, Y_train, Y_test = train_test_split(X_s, Y, stratify = Y, random_state = 0)

###################################################################
#################   Outputting the models   #######################
###################################################################
results = []
models = [('Logist Regression', LogisticRegression()), ('Support Vector Machine', SVC()), ('K-Nearest Neighbors', 
KNeighborsClassifier(n_neighbors = 3)), ('Naive Bayes Gaussian', GaussianNB()), ('Perceptron', Perceptron()), 
('Linear Support Vector Machine', LinearSVC()), ('Decision Tree', DecisionTreeClassifier()), ('Random Forest', 
RandomForestClassifier(n_estimators=100))]

Lowest_Name = ''
Lowest_Percentage = 100

Highest_Name = ''
Highest_Percentage = 0

print("##########  Overall Results  ##########")
for name, model in models:
    model.fit(X_train, Y_train)
    Y_pred = model.predict(X_test)
    accuracy = round(model.score(X_train, Y_train) * 100, 2)
    print(name + " " + str(accuracy) +"%")
    results.append(accuracy)
    # Best result
    if round(model.score(X_train, Y_train) * 100, 2) > Highest_Percentage:
        Highest_Name = name
        Highest_Percentage = round(model.score(X_train, Y_train) * 100, 2)
    # Worst result
    if round(model.score(X_train, Y_train) * 100, 2) < Lowest_Percentage:
        Lowest_Name = name
        Lowest_Percentage = round(model.score(X_train, Y_train) * 100, 2)
print("")
print("##########  Summary  ##########")
print("Our best result was from " + str(Highest_Name) + " with a result of " + str(Highest_Percentage) + "%.")
print("Our least effective result was from " + str(Lowest_Name) + " with a result of " + str(Lowest_Percentage) + "%.")


