import numpy as np
import pandas as pd
from sklearn import metrics
import json

# ML Models
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.linear_model import Perceptron
from sklearn.neural_network import MLPClassifier

# Save results to json function
def saveResults(dct):
    json.dump(dct, open("C:/Users/clays/OneDrive/Documents/GitHub/CaliforniaHousingModel/results.json", "w"), indent=4)


# Uploading Data
df = pd.read_csv(r'C:/Users/clays/OneDrive/Documents/GitHub/CaliforniaHousingModel/housing.csv')
data = pd.read_csv(r'C:/Users/clays/OneDrive/Documents/GitHub/CaliforniaHousingModel/housing_test_final_project.csv')
df = df[:1000]

combine = [df, data]

# Classifying the ocean proximity
#1 is what I considered the most scenic, 5 is the least
for dataset in combine:
	dataset['ocean_proximity'] = dataset['ocean_proximity'].map( { 'ISLAND':1, 'NEAR OCEAN':2, 
	'NEAR BAY':3, '<1H OCEAN':4, 'INLAND':5} ).astype(int)

# Classifying the housing_median_age column 
#(this is more out of curiosity to see the impact than it is actually helpful)
for dataset in combine:    
    dataset.loc[ dataset['housing_median_age'] <= 10, 'housing_median_age'] = 0
    dataset.loc[(dataset['housing_median_age'] > 10) & (dataset['housing_median_age'] <= 20), 'housing_median_age'] = 1
    dataset.loc[(dataset['housing_median_age'] > 20) & (dataset['housing_median_age'] <= 30), 'housing_median_age'] = 2
    dataset.loc[(dataset['housing_median_age'] > 30) & (dataset['housing_median_age'] <= 40), 'housing_median_age'] = 3
    dataset.loc[ dataset['housing_median_age'] > 40, 'housing_median_age'] = 5

# Filling all NaNs with the median total_bedrooms value
df['total_bedrooms'].fillna(df['total_bedrooms'].dropna().median(), inplace=True)
data['total_bedrooms'].fillna(data['total_bedrooms'].dropna().median(), inplace=True)

# Dropping the columns that I don't care to incorporate (or dropping the Y variable from the X)
xTrain = df.drop(["median_house_value", "latitude", "longitude"], axis = 1)
yTrain = df["median_house_value"]
xTest = data.drop(["latitude", "longitude"], axis = 1)


###################################################################
#################   Outputting the models   #######################
###################################################################
models = []
models.append(('Linear Discriminant Analysis', LinearDiscriminantAnalysis())) 
models.append(('K-Nearest Neighbors', KNeighborsClassifier(n_neighbors = 1)))
models.append(('Naive Bayes Gaussian', GaussianNB()))
# ('Logist Regression', LogisticRegression(random_state=0, max_iter=700)), 
models.append(('Support Vector Machine', SVC())) 
models.append(('Decision Tree', DecisionTreeClassifier()))
models.append(('MLP', MLPClassifier(random_state=0, max_iter=700)))
models.append(('Perceptron', Perceptron()))
 
dct = {}

for name, model in models:
    dct1 = {}
    # Fitting the model 
    model.fit(xTrain, yTrain)
    # Resulting accuracy
    accuracy = round(model.score(xTrain, yTrain) * 100, 2)
    for i in range(len(data['longitude'])):
        dct1["Accuracy"] = accuracy
        # Beginning a new section to report the model prediction
        if i == 0:
            print("############         " + name + " Predictions         ############")
            print('    Accuracy: ', accuracy, '%', sep = "") # Spaced accuracy out just because it makes it clear it's not a prediction in the output
        # Below loops through each row of our test csv file and gives us a prediction based on our model
        pred = model.predict([[data['housing_median_age'][i], data['total_rooms'][i], 
        data['total_bedrooms'][i], data['population'][i], data['households'][i], data['median_income'][i], data['ocean_proximity'][i]]])
        pred = int(pred)
        # Saving predictions by row number
        dct1["Prediction_" + str(i + 1)] = pred
        print("Row ", i+1, ": ", pred, sep = "")
    dct[name] = dct1

# Saving my results to a json file
saveResults(dct)