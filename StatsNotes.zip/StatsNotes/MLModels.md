# <center> Machine/Statistical Learning Model Notes</center> 
---
Author: Tyler Clayson

### Random Forest Models
I've used this [site](https://www.section.io/engineering-education/introduction-to-random-forest-in-machine-learning/) as a reference since it was simple to understand and will be an easy way for me to refresh on the topic if I forget. <br />
Random forests are a culmination of several different decision trees. After the creation of $N$ decision trees, predictions are made based on how many decision trees came to a certain conclusion. ![RF](randomForest.png) In this example, there were 2 of the the 3 decision trees that came to a decision of an apple based on the hypothetical parameters that were met. i.e. you could have an image that is round = yes, red = yes, therefore it's an apple. <br />
This does require a fair amount of data though in order to have power in it's predictions. 

---