from PIL import Image
import numpy as np
import cv2

# load the image
image = cv2.imread("/Users/clays/OneDrive/Documents/Python/images/bush.jpg")
# convert image to numpy array
data = np.asarray(image)
print(type(data))
# summarize shape
print(data.shape)
# create Pillow image
image2 = Image.fromarray(data)
print(type(image2))
# summarize image details
print(image2.mode)
print(image2.size)
print(data)