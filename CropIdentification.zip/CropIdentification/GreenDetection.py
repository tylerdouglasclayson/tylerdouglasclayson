### Row Detect Packages
import numpy as np # Array Conversion, Iterating through folder files, and Green Detect as well
import math
import matplotlib.pyplot as plt
from matplotlib import cm, gridspec
#geospatial libraries
# import rasterio
import fiona
import geopandas as gpd
#machine learning libraries
#pip install scikit-image
from skimage import feature
from skimage.transform import hough_line, hough_line_peaks

### Green Detect Packages
import cv2 # Iterating through folder files, Array Conversion as well

### Iterating through folder files
import os
import argparse

img = cv2.imread("C:/Users/clays/OneDrive/Documents/Python/Capstone/practice/bill.jpg")

def GreenDetect(img, path, filename):
    # This is the green conversion/mask convert to hsv
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    ## mask of green (36,25,25) ~ (86, 255,255)
    # mask1 = cv2.inRange(hsv, (50, 25, 25), (86, 255,255)) # Green color range
    # mask2 = cv2.inRange(hsv, (15,0,0), (36, 255, 255)) # Yellow color range
    # mask = cv2.bitwise_or(mask1, mask2)

    ## mask of green (36,25,25) ~ (86, 255,255)
    # mask = cv2.inRange(hsv, (15,0,0), (36, 255, 255)) #Yellow
    mask = cv2.inRange(hsv, (36, 25, 25), (86, 255,255))
    # mask = cv2.inRange(hsv, (36, 25, 25), (70, 255,255))
    # slice the green
    imask = mask > 0
    green = np.zeros_like(img, np.uint8)
    green[imask] = img[imask]

    # Extracting only the green pixels
    imask = mask > 0
    green = np.zeros_like(img, np.uint8)
    green[imask] = img[imask]
    
    # Saves green image with new file name
    newFileName = "green" + filename.split()[0]
    cv2.imwrite(os.path.join(path, newFileName), green) 

GreenDetect(img, "C:/Users/clays/OneDrive/Documents/Python/Capstone/ResultingGreenDetect", "test.png")