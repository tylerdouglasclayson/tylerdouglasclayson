### Row Detect Packages
import numpy as np # Array Conversion, Iterating through folder files, and Green Detect as well
import math
import matplotlib.pyplot as plt
from matplotlib import cm, gridspec
#geospatial libraries
import rasterio
import fiona
import geopandas as gpd
#machine learning libraries
#pip install scikit-image
from skimage import feature
from skimage.transform import hough_line, hough_line_peaks

### Green Detect Packages
import cv2 # Iterating through folder files, Array Conversion as well

### Iterating through folder files
import os
import argparse

### Array Conversion Packages
from PIL import Image

from os.path import exists

###########    Functions    #############

# Green detection
def GreenDetect(img, path, filename):
    # This is the green conversion/mask convert to hsv
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    ## mask of green (36,25,25) ~ (86, 255,255)
    mask1 = cv2.inRange(hsv, (35, 25, 25), (66, 255,255)) # Green color range
    # mask2 = cv2.inRange(hsv, (15,0,0), (36, 255, 255)) # Yellow color range
    # mask = cv2.bitwise_or(mask1, mask2)

    # Extracting only the green pixels
    imask = mask1 > 0
    green = np.zeros_like(img, np.uint8)
    green[imask] = img[imask]
    
    # Saves green image with new file name
    newFileName = "green" + filename.split()[0]
    cv2.imwrite(os.path.join(path, newFileName), green) 

# Row Detection
def RowDetection(directory, path, filename):
    imgRaster = rasterio.open(directory + "/" + filename)
    im = imgRaster.read(1)
    fig = plt.figure(figsize=(12, 8))
    # Compute the Canny filter for one value of sigma
    # png creates more noise than jpg, so we'll adjust the sigma accordingly
    if filename.endswith(".jpg"):
        edges1 = feature.canny(im, sigma = 3) 
    elif filename.endswith(".png"):
        edges1 = feature.canny(im, sigma = 2) #Sigma responds with more noise on png than jpg
    
    fig, (ax1) = plt.subplots(nrows=1, ncols=1, figsize=(9, 6),
                                        sharex=True, sharey=True)

    ax1.imshow(edges1, cmap=plt.cm.gray)
    fig.tight_layout()

    fig.savefig(path + "/row_" + filename.split()[0])

# Converting an image to an array
def ImageToArray(img):
    data = np.asarray(img)
    return data


###########    LOGIC SECTION    #############

# Assign directory and paths
directory = "C:/Users/clays/OneDrive/Documents/GitHub/CropIdentification/SatImages"
greenPath = "C:/Users/clays/OneDrive/Documents/GitHub/CropIdentification/ResultingGreenDetect"
rowPath = "C:/Users/clays/OneDrive/Documents/GitHub/CropIdentification/ResultingRowDetect"

# Green Detection
for filename in os.listdir(directory):
    # checking if it is an image file we can work with
    if filename.endswith(".jpg") or filename.endswith(".png"):
        # Read
        f = os.path.join(directory, filename)
        img = cv2.imread(f)
        
        GreenDetect(img, greenPath, filename)
# Row Detection
for filename in os.listdir(greenPath):
    if filename.endswith(".jpg") or filename.endswith(".png"):
        f = os.path.join(directory, filename)
        
        RowDetection(greenPath, rowPath, filename)

#User input
boole = True
tryAgain = "The request you submitted was not recognized. Please try again.\n"
anotherImage = "Would you like to see the array for another image? (y/n) "
while boole:
    resp = str(input("Is there an image you would like an array of? (y/n) ")).lower()
    if resp == "y" or resp == "n":
        boole = False
    else:
        print(tryAgain)

while resp == "y":
    resp2 = str(input("What image would you like to see? \n(Just type the original image name with .jpg or .png) "))
    imagePath = rowPath + "/row_green" + resp2
    if exists(imagePath):
        img = cv2.imread(imagePath)
        print(ImageToArray(img))
        resp = str(input(anotherImage)).lower()
        if resp != "y" or resp != "n":
            boole = True
            while boole:
                resp = str(input(tryAgain + anotherImage)).lower()
                if resp == "y" or resp == "n":
                    boole = False
    else:
        resp = str(input("The image you've requested does not exist. Would you like to retype it? (y/n) ")).lower()
        if resp != "y" or resp != "n":
            pass
        else:
            boole = True
            while boole:
                resp = str(input(tryAgain + anotherImage)).lower()
                if resp == "y" or resp == "n":
                    boole = False

print("END OF REPORT")
