##### Summary:
This project was created with Andrew Walker, Jordan Worthen, and myself. The hope is for it to motivate questions such as production volume from crop production year to year, or identifying diseases/nutrition deficiencies in a field. The dilemma you'll find however with using satellites is that one pixel of an image might be too large of an area for the discovery of a disease to matter. By the time a pixel shows it, the field is already overrun. However, I think this could be more useful once the use of drones becomes more prevalent. 

##### Organization of the Folder:
This folder contains sample photos we've collected and processed. It also holds independent python files for each procedure we've used as I intend to use object oriented programming to clean the code up. 